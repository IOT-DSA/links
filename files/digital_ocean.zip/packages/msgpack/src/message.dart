part of msgpack;

abstract class Message {
  List toList();
}
