/// Placeholder for future socket server support.
library dslink.socket_server;
