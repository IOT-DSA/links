# Cursor Source

Cursor files are from Google:

* https://mail.google.com/mail/u/0/images/2/openhand.cur
* https://mail.google.com/mail/u/0/images/2/closedhand.cur

or 

* http://maps.google.com/mapfiles/openhand.cur
* http://maps.google.com/mapfiles/closedhand.cur