require("babel/register")({
  only: /lib/
});
require('./lib');
