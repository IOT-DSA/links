/// Placeholder for future socket client support.
library dslink.socket_client;
