library test2;

class Test2 {
}
