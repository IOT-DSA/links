//class A {
//  operator + (x) {}
//}
//class B extends A {
//  operator + (x) {}
//}

/**
 * [MyEnum] zzz
 */
enum MyEnum {
  /**
   * [int] aaa
   */
  A,
  /// [A]
  B,
  C
}

class A {
  void m() {}
}

class B extends A {
  operator + (x) {}
  void m() {}
}

abstract class I {
  void m();
}

abstract class J extends I {
  void m();
}

class C extends B implements J {
  void m() {}
  operator + (x) {}
}

class D implements J {
  void m() {}
}
