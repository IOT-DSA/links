library test3;

import 'test2.dart';

A newA() => new A();
B newB() => new B();
